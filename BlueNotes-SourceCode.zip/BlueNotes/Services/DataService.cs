using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using BlueNotes.Models;

namespace BlueNotes.Services
{
    public class DataService
    {
        private static readonly string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "BlueNotes");

        private static readonly string NotesFile = Path.Combine(DataDir, "notes.json");
        private static readonly string CategoriesFile = Path.Combine(DataDir, "categories.json");
        private static readonly string SettingsFile = Path.Combine(DataDir, "settings.json");

        private List<Note> _notes = new();
        private List<NoteCategory> _categories = new();
        private AppSettings _settings = new();

        public DataService()
        {
            Directory.CreateDirectory(DataDir);
            MigrateFromOldDataDir();
            Load();
        }

        // 从旧 StickyNotes 数据目录迁移到新 BlueNotes 目录
        private static void MigrateFromOldDataDir()
        {
            var oldDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "StickyNotes");
            if (!Directory.Exists(oldDir)) return;

            var newSettings = Path.Combine(DataDir, "settings.json");
            // 仅在新目录还没有任何数据文件时才自动迁移
            if (File.Exists(newSettings)) return;

            try
            {
                foreach (var file in Directory.GetFiles(oldDir))
                {
                    var dest = Path.Combine(DataDir, Path.GetFileName(file));
                    File.Copy(file, dest, overwrite: false);
                }
            }
            catch { /* 迁移失败不影响正常启动 */ }
        }

        // ===== Notes =====
        public List<Note> GetNotes(string? categoryId = null)
        {
            if (categoryId == null || categoryId == "all")
                return _notes;
            return _notes.FindAll(n => n.CategoryId == categoryId);
        }

        public Note AddNote(Note note)
        {
            _notes.Insert(0, note);
            SaveNotes();
            return note;
        }

        public void UpdateNote(Note note)
        {
            var idx = _notes.FindIndex(n => n.Id == note.Id);
            if (idx >= 0)
            {
                note.UpdatedAt = DateTime.Now;
                _notes[idx] = note;
                SaveNotes();
            }
        }

        public void DeleteNote(string id)
        {
            _notes.RemoveAll(n => n.Id == id);
            SaveNotes();
        }

        // ===== Categories =====
        public List<NoteCategory> GetCategories() => _categories;

        public void AddCategory(NoteCategory cat)
        {
            _categories.Add(cat);
            SaveCategories();
        }

        public void DeleteCategory(string id)
        {
            _categories.RemoveAll(c => c.Id == id && !c.IsSystem);
            SaveCategories();
        }

        // ===== Settings =====
        public AppSettings GetSettings() => _settings;

        public bool HasSettingsFile() => File.Exists(SettingsFile);

        public void SaveSettings(AppSettings settings)
        {
            _settings = settings;
            File.WriteAllText(SettingsFile, JsonConvert.SerializeObject(settings, Formatting.Indented));
        }

        // ===== IO =====
        private void Load()
        {
            // Load notes
            if (File.Exists(NotesFile))
            {
                try { _notes = JsonConvert.DeserializeObject<List<Note>>(File.ReadAllText(NotesFile)) ?? new(); }
                catch { _notes = new(); }
            }

            // Load categories
            if (File.Exists(CategoriesFile))
            {
                try { _categories = JsonConvert.DeserializeObject<List<NoteCategory>>(File.ReadAllText(CategoriesFile)) ?? NoteCategory.GetDefaults(); }
                catch { _categories = NoteCategory.GetDefaults(); }
            }
            else
            {
                _categories = NoteCategory.GetDefaults();
                SaveCategories();
            }

            // Load settings
            if (File.Exists(SettingsFile))
            {
                try { _settings = JsonConvert.DeserializeObject<AppSettings>(File.ReadAllText(SettingsFile)) ?? new(); }
                catch { _settings = new(); }
            }
        }

        private void SaveNotes()
        {
            File.WriteAllText(NotesFile, JsonConvert.SerializeObject(_notes, Formatting.Indented));
        }

        private void SaveCategories()
        {
            File.WriteAllText(CategoriesFile, JsonConvert.SerializeObject(_categories, Formatting.Indented));
        }

        // ===== Export/Import =====
        public string ExportToJson()
        {
            var data = new { notes = _notes, categories = _categories };
            return JsonConvert.SerializeObject(data, Formatting.Indented);
        }

        public bool ImportFromJson(string json)
        {
            try
            {
                dynamic? data = JsonConvert.DeserializeObject(json);
                if (data?.notes != null)
                    _notes = JsonConvert.DeserializeObject<List<Note>>(data.notes.ToString()) ?? _notes;
                if (data?.categories != null)
                    _categories = JsonConvert.DeserializeObject<List<NoteCategory>>(data.categories.ToString()) ?? _categories;
                SaveNotes();
                SaveCategories();
                return true;
            }
            catch { return false; }
        }
    }
}
