using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using BlueNotes.Models;

namespace BlueNotes
{
    public partial class NoteEditWindow : Window
    {
        public Note? ResultNote { get; private set; }
        private Note _note;
#pragma warning disable CS0414
        private bool _isNew;  // 区分新建/编辑模式，供后续扩展
#pragma warning restore CS0414

        // 新建便签
        public NoteEditWindow(string categoryId)
        {
            InitializeComponent();
            _isNew = true;
            _note = new Note { CategoryId = categoryId };
            DialogTitle.Text = "新建便签";
            SetupPlaceholders();
        }

        // 编辑现有便签
        public NoteEditWindow(Note note)
        {
            InitializeComponent();
            _isNew = false;
            _note = note;
            DialogTitle.Text = "编辑便签";
            LoadNote();
            SetupPlaceholders();
        }

        private void LoadNote()
        {
            TitleBox.Text = _note.Title;
            ContentBox.Text = _note.Content;
            PinnedCheck.IsChecked = _note.IsPinned;

            // 设置颜色
            switch (_note.Color)
            {
                case NoteColor.Green: ColorGreen.IsChecked = true; break;
                case NoteColor.Pink: ColorPink.IsChecked = true; break;
                case NoteColor.Blue: ColorBlue.IsChecked = true; break;
                case NoteColor.Orange: ColorOrange.IsChecked = true; break;
                default: ColorYellow.IsChecked = true; break;
            }

            // 设置提醒
            if (_note.ReminderTime.HasValue)
            {
                ReminderPanel.Visibility = Visibility.Visible;
                ReminderText.Text = $"⏰ 提醒：{_note.ReminderTime.Value:MM/dd HH:mm}";
            }

            UpdateBackground();
        }

        private void SetupPlaceholders()
        {
            // 标题占位符
            TitleBox.GotFocus += (s, e) =>
            {
                if (TitleBox.Text == (string)TitleBox.Tag)
                {
                    TitleBox.Text = "";
                    TitleBox.Foreground = new SolidColorBrush(Colors.Black);
                }
            };
            TitleBox.LostFocus += (s, e) =>
            {
                if (string.IsNullOrEmpty(TitleBox.Text))
                {
                    TitleBox.Text = (string)TitleBox.Tag;
                    TitleBox.Foreground = new SolidColorBrush(Colors.Gray);
                }
            };

            // 内容占位符
            ContentBox.GotFocus += (s, e) =>
            {
                if (ContentBox.Text == (string)ContentBox.Tag)
                {
                    ContentBox.Text = "";
                    ContentBox.Foreground = new SolidColorBrush(Colors.Black);
                }
            };
            ContentBox.LostFocus += (s, e) =>
            {
                if (string.IsNullOrEmpty(ContentBox.Text))
                {
                    ContentBox.Text = (string)ContentBox.Tag;
                    ContentBox.Foreground = new SolidColorBrush(Colors.Gray);
                }
            };

            // 初始化占位符状态
            if (string.IsNullOrEmpty(TitleBox.Text))
            {
                TitleBox.Text = (string)TitleBox.Tag;
                TitleBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
            if (string.IsNullOrEmpty(ContentBox.Text))
            {
                ContentBox.Text = (string)ContentBox.Tag;
                ContentBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        private void Color_Changed(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton rb && rb.Tag is string colorName)
            {
                _note.Color = Enum.Parse<NoteColor>(colorName);
                UpdateBackground();
            }
        }

        private void UpdateBackground()
        {
            var color = (Color)ColorConverter.ConvertFromString(_note.ColorHex);
            MainBorder.Background = new SolidColorBrush(color);
        }

        private void SetReminder(object sender, MouseButtonEventArgs e)
        {
            // 简单的日期时间输入对话框
            var dlg = new InputDialog("设置提醒", "请输入提醒时间（格式：yyyy-MM-dd HH:mm）：", 
                _note.ReminderTime?.ToString("yyyy-MM-dd HH:mm") ?? DateTime.Now.AddHours(1).ToString("yyyy-MM-dd HH:mm"))
            {
                Owner = this
            };
            if (dlg.ShowDialog() == true)
            {
                // 只接受固定格式，避免解析失败
                var formats = new[] { "yyyy-MM-dd HH:mm" };
                if (DateTime.TryParseExact(dlg.Result, formats, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var dt))
                {
                    // 标准化为本地时间，秒归零
                    dt = DateTime.SpecifyKind(new DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, 0), DateTimeKind.Local);
                    _note.ReminderTime = dt;
                    ReminderPanel.Visibility = Visibility.Visible;
                    ReminderText.Text = $"⏰ 提醒：{dt:MM/dd HH:mm}";
                }
                else
                {
                    MessageBox.Show("时间格式不正确，请使用格式：yyyy-MM-dd HH:mm", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void ClearReminder_Click(object sender, RoutedEventArgs e)
        {
            _note.ReminderTime = null;
            ReminderPanel.Visibility = Visibility.Collapsed;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var title = TitleBox.Text == (string)TitleBox.Tag ? "" : TitleBox.Text.Trim();
            var content = ContentBox.Text == (string)ContentBox.Tag ? "" : ContentBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(content) && string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("请填写便签内容！", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _note.Title = title;
            _note.Content = content;
            _note.IsPinned = PinnedCheck.IsChecked == true;

            ResultNote = _note;
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // 仅在按下主鼠标按钮且鼠标在标题栏区域时允许拖动，避免 InvalidOperationException
            if (e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed && e.GetPosition(this).Y <= 40)
            {
                try { DragMove(); }
                catch { }
            }
        }
    }
}
