using System;
using System.Collections.Generic;

namespace BlueNotes.Models
{
    // 便签类型枚举
    public enum NoteType
    {
        Normal,     // 普通便签
        Todo,       // 待办事项
        Reminder,   // 提醒
        Timeline,   // 时间计划
        Bookmark    // 攻坚目标
    }

    // 便签颜色
    public enum NoteColor
    {
        Yellow,
        Green,
        Pink,
        Blue,
        Orange,
        White
    }

    // 便签优先级
    public enum NotePriority
    {
        Normal,
        High,
        Urgent
    }

    // 便签实体
    public class Note
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
        public NoteType Type { get; set; } = NoteType.Normal;
        public NoteColor Color { get; set; } = NoteColor.Yellow;
        public NotePriority Priority { get; set; } = NotePriority.Normal;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
        public bool IsCompleted { get; set; } = false;
        public bool IsAbandoned { get; set; } = false;
        public bool IsPinned { get; set; } = false;
        public DateTime? ReminderTime { get; set; }
        public string CategoryId { get; set; } = "default";

        // 显示用颜色
        public string ColorHex => Color switch
        {
            NoteColor.Yellow => "#FFF9E4A8",
            NoteColor.Green => "#FF90EE90",
            NoteColor.Pink => "#FFFF9999",
            NoteColor.Blue => "#FF87CEEB",
            NoteColor.Orange => "#FFFFA07A",
            NoteColor.White => "#FFFFFFFF",
            _ => "#FFF9E4A8"
        };

        // 标签头颜色（深一点）
        public string HeaderColorHex => Color switch
        {
            NoteColor.Yellow => "#FFF5D060",
            NoteColor.Green => "#FF5CBF5C",
            NoteColor.Pink => "#FFFF6B6B",
            NoteColor.Blue => "#FF5BA3C9",
            NoteColor.Orange => "#FFFF8C00",
            NoteColor.White => "#FFCCCCCC",
            _ => "#FFF5D060"
        };

        public string DisplayTitle => string.IsNullOrWhiteSpace(Title)
            ? CreatedAt.ToString("yyyy-MM-dd HH:mm")
            : Title;
    }

    // 便签分类
    public class NoteCategory
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public NoteType Type { get; set; } = NoteType.Normal;
        public string Icon { get; set; } = "📝";
        public bool IsSystem { get; set; } = false;
        public int SortOrder { get; set; } = 0;

        public static List<NoteCategory> GetDefaults()
        {
            return new List<NoteCategory>
            {
                new() { Id = "normal", Name = "普通便签", Type = NoteType.Normal, Icon = "📝", IsSystem = true, SortOrder = 0 },
                new() { Id = "todo", Name = "待办事项", Type = NoteType.Todo, Icon = "✅", IsSystem = true, SortOrder = 1 },
                new() { Id = "reminder", Name = "我的提醒", Type = NoteType.Reminder, Icon = "⏰", IsSystem = true, SortOrder = 2 },
                new() { Id = "bookmark", Name = "攻坚目标", Type = NoteType.Bookmark, Icon = "🎯", IsSystem = true, SortOrder = 3 },
                new() { Id = "timeline", Name = "时间计划", Type = NoteType.Timeline, Icon = "📅", IsSystem = true, SortOrder = 4 },
            };
        }
    }

    // 应用设置
    public class AppSettings
    {
        public double WindowLeft { get; set; } = 100;
        public double WindowTop { get; set; } = 100;
        public double WindowWidth { get; set; } = 320;
        public double WindowHeight { get; set; } = 600;
        public bool IsDockedLeft { get; set; } = false;
        public bool IsDockedRight { get; set; } = false;
        public bool AutoHideWhenDocked { get; set; } = true;
        public bool ShowTodayTodo { get; set; } = true;
        public bool AlwaysOnTop { get; set; } = false;
        public string LastCategoryId { get; set; } = "normal";
        public double Opacity { get; set; } = 1.0;
        public bool RunAtStartup { get; set; } = false;
    }
}
