using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace BlueNotes
{
    public partial class App : Application
    {
        private static Mutex? _mutex;
        private System.Windows.Forms.NotifyIcon? _trayIcon;

        // 用于向已运行实例发送"显示窗口"消息
        private const int HWND_BROADCAST = 0xFFFF;
        private static readonly uint WM_SHOWBLUENOTES =
            RegisterWindowMessage("WM_SHOWBLUENOTES_2026");

        [DllImport("user32.dll")]
        private static extern bool PostMessage(IntPtr hwnd, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern uint RegisterWindowMessage(string lpString);

        protected override void OnStartup(StartupEventArgs e)
        {
            const string mutexName = "BlueNotes_SingleInstance_Mutex";
            _mutex = new Mutex(true, mutexName, out bool createdNew);

            if (!createdNew)
            {
                // 已有实例在运行 — 发消息让它显示，然后退出
                PostMessage((IntPtr)HWND_BROADCAST, WM_SHOWBLUENOTES, IntPtr.Zero, IntPtr.Zero);
                _mutex.Dispose();
                Shutdown();
                return;
            }

            base.OnStartup(e);
            InitTrayIcon();
        }

        private void InitTrayIcon()
        {
            _trayIcon = new System.Windows.Forms.NotifyIcon
            {
                Text = "桌面便签",
                Visible = true
            };

            // 使用内置图标
            try
            {
                var iconPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "note.ico");
                if (System.IO.File.Exists(iconPath))
                    _trayIcon.Icon = new System.Drawing.Icon(iconPath);
                else
                    _trayIcon.Icon = System.Drawing.SystemIcons.Application;
            }
            catch
            {
                _trayIcon.Icon = System.Drawing.SystemIcons.Application;
            }

            var contextMenu = new System.Windows.Forms.ContextMenuStrip();
            contextMenu.Items.Add("显示主窗口", null, (s, e) => ShowMainWindow());
            contextMenu.Items.Add("新建便签", null, (s, e) => ShowMainWindow());
            contextMenu.Items.Add("-");
            contextMenu.Items.Add("退出", null, (s, e) => ExitApp());

            _trayIcon.ContextMenuStrip = contextMenu;
            _trayIcon.DoubleClick += (s, e) => ShowMainWindow();
        }

        private void ShowMainWindow()
        {
            if (MainWindow != null)
            {
                MainWindow.Show();
                MainWindow.WindowState = WindowState.Normal;
                MainWindow.Activate();
            }
        }

        private void ExitApp()
        {
            // 退出前显式保存主窗口的可见位置（不依赖 Window_Closing 事件）
            if (MainWindow is MainWindow mw)
            {
                mw.SavePositionOnExit();
            }
            _trayIcon?.Dispose();
            Shutdown();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _trayIcon?.Dispose();
            _mutex?.ReleaseMutex();
            _mutex?.Dispose();
            base.OnExit(e);
        }

        // 供 MainWindow 获取消息 ID，用于注册 WndProc 监听
        public static uint ShowWindowMessage => WM_SHOWBLUENOTES;
    }
}
