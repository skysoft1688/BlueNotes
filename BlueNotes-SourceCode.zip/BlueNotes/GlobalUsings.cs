// WPF global using directives
// WinForms types must be fully qualified (System.Windows.Forms.xxx / System.Drawing.xxx)
global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.IO;
global using System.Windows;
global using System.Windows.Controls;
global using System.Windows.Input;
global using System.Windows.Media;
global using System.Windows.Threading;
global using System.Windows.Media.Animation;
global using System.Windows.Media.Effects;
global using System.ComponentModel;
