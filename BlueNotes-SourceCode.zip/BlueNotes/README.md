# 桌面便签 StickyNotes - 构建说明

## 项目结构
```
StickyNotes/
├── StickyNotes.csproj          # 项目文件
├── App.xaml / App.xaml.cs      # 应用入口 + 系统托盘
├── MainWindow.xaml / .cs       # 主窗口（多标签 + 贴边停靠）
├── NoteEditWindow.xaml / .cs   # 便签编辑窗口
├── InputDialog.xaml / .cs      # 通用输入对话框
├── Models/
│   └── NoteModels.cs           # 数据模型（Note, NoteCategory, AppSettings）
└── Services/
    └── DataService.cs          # 本地 JSON 数据存储服务
```

## 依赖
- .NET 8.0 Windows
- WPF + Windows Forms（系统托盘）
- Newtonsoft.Json 13.0.3

## 构建步骤

### 方式一：Visual Studio 2022
1. 打开 Visual Studio 2022
2. 文件 → 打开 → 项目/解决方案 → 选择 `StickyNotes.csproj`
3. 等待 NuGet 包还原
4. 按 F5 运行，或 Ctrl+Shift+B 生成

### 方式二：命令行
```bash
cd StickyNotes
dotnet restore
dotnet build
dotnet run
```

### 发布为单文件 exe
```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o ./publish
```

## 主要功能

### 1. 多标签分类
- 左侧分类栏：普通便签、待办、提醒、攻坚目标、时间轴
- 支持新建自定义分类
- 分类按钮显示未完成便签数量

### 2. 贴边停靠 + 自动隐藏
- 将窗口拖到屏幕左/右边缘，自动吸附
- 鼠标离开后 1.5 秒自动滑入隐藏（露出 8px 边条）
- 鼠标移入边条区域自动滑出展开
- 贴边后窗口垂直位置可自由调整
- 菜单中可关闭"自动隐藏"功能

### 3. 便签管理
- 新建/编辑/删除便签
- 5 种颜色标签（黄/绿/粉/蓝/橙）
- 便签置顶
- 设置提醒时间
- 搜索便签内容

### 4. 已完成/放弃
- 点击"已完成/已放弃"切换显示已完成便签列表

### 5. 系统托盘
- 关闭窗口后最小化到系统托盘
- 双击托盘图标重新显示
- 右键菜单：显示、退出

### 6. 数据持久化
- 便签数据保存在 `%AppData%\StickyNotes\`
- 支持 JSON 导入/导出
- 窗口位置、大小、置顶状态均自动保存

## 可选：添加图标
在 Resources/ 目录下放入 note.ico 文件（16×16 到 256×256 的多尺寸 ICO）
否则程序使用系统默认图标。
