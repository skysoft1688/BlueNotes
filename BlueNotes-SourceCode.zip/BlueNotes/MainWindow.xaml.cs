using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using BlueNotes.Models;
using BlueNotes.Services;
using System.Reflection;
using System.IO;
using System.Media;
using Microsoft.Win32;

namespace BlueNotes
{
    public partial class MainWindow : Window
    {
        private readonly DataService _data = new();
        private string _currentCategoryId = "normal";
        private bool _showCompleted = false;
        private string _searchText = "";
        private bool _isDocked = false;
        private DockSide _dockSide = DockSide.None;
        private bool _isHidden = false;         // 贴边隐藏状态
        private bool _isAnimating = false;     // 正在执行贴边动画（禁止 CheckDockState 干扰）
        private bool _isDragging = false;      // 正在拖拽窗口（禁止自动隐藏）
        private bool _suppressStateChanged = false; // 动画期间禁止 Window_StateChanged 干扰
        private bool _isExiting = false;           // 正在退出，禁止任何后续保存覆盖
        private bool _isLoading = true;            // 正在启动，禁止 SaveWindowState 覆盖退出保存的位置
#pragma warning disable CS0414
        private double _hiddenLeft = 0;          // 隐藏时的X
        private double _hiddenTop = 0;           // 隐藏时的Y
#pragma warning restore CS0414
        private double _visibleLeft = 0;         // 显示时的X
        private double _visibleTop = 0;          // 显示时的Y
        private double _lastSaveLeft = 0;        // 最后一次保存的X（持续追踪，退出时用到）
        private double _lastSaveTop = 0;         // 最后一次保存的Y
        private const double DOCK_THRESHOLD = 20;   // 贴边触发距离
        private const double HIDDEN_WIDTH = 8;      // 水平缩进后露出的宽度
        private const double HIDDEN_HEIGHT = 8;     // 垂直缩进后露出的高度
        private DispatcherTimer _autoHideTimer = new();
        private DispatcherTimer _showTimer = new();
        private DispatcherTimer _reminderTimer = new();
        private readonly HashSet<string> _notifiedReminders = new();

        private enum DockSide { None, Left, Right, Top, Bottom }

        public MainWindow()
        {
            InitializeComponent();
            StateChanged += Window_StateChanged;
            SourceInitialized += (s, e) =>
            {
                var hwnd = new WindowInteropHelper(this).Handle;
                HwndSource.FromHwnd(hwnd)?.AddHook(SingleInstanceWndProc);
            };
            InitTimers();
        }

        private void InitTimers()
        {
            _autoHideTimer.Interval = TimeSpan.FromMilliseconds(1500);
            _autoHideTimer.Tick += (s, e) =>
            {
                _autoHideTimer.Stop();
                if (_isDragging) return; // 拖拽中不隐藏
                var st = _data.GetSettings();
                if (st.AutoHideWhenDocked && _isDocked && !_isHidden && IsMouseOutOfWindow())
                    SlideHide();
            };

            _showTimer.Interval = TimeSpan.FromMilliseconds(200);
            _showTimer.Tick += (s, e) =>
            {
                _showTimer.Stop();
            };

            // 提醒检查定时器（每秒检查一次）
            _reminderTimer.Interval = TimeSpan.FromSeconds(1);
            _reminderTimer.Tick += (s, e) => CheckReminders();
            _reminderTimer.Start();
        }

        // 禁止 Windows 在拖到顶边时最大化窗口（动画期间不拦截，避免位置跳变）
        private void Window_StateChanged(object? sender, EventArgs e)
        {
            if (_suppressStateChanged) return;
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
        }

        // 单实例：接收广播消息并激活主窗口
        private IntPtr SingleInstanceWndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if ((uint)msg == App.ShowWindowMessage)
            {
                if (WindowState == WindowState.Minimized)
                    WindowState = WindowState.Normal;
                Show();
                Activate();
                // 若处于贴边隐藏状态则滑出
                if (_isHidden) SlideShow();
                handled = true;
            }
            return IntPtr.Zero;
        }

        private void CheckReminders()
        {
            try
            {
                var now = DateTime.Now;
                var notes = _data.GetNotes();
                foreach (var note in notes)
                {
                    // 清理已修改为将来时间的提醒标记
                    if (_notifiedReminders.Contains(note.Id))
                    {
                        if (!note.ReminderTime.HasValue || note.ReminderTime.Value > now)
                        {
                            _notifiedReminders.Remove(note.Id);
                        }
                    }

                    if (note.ReminderTime.HasValue && !note.IsCompleted && !_notifiedReminders.Contains(note.Id))
                    {
                        var rt = note.ReminderTime.Value;
                        // 统一将提醒时间视为本地时间进行比较
                        if (rt.Kind == DateTimeKind.Utc)
                            rt = rt.ToLocalTime();
                        else if (rt.Kind == DateTimeKind.Unspecified)
                            rt = DateTime.SpecifyKind(rt, DateTimeKind.Local);

                        // 仅在提醒时间已到且未超过 1 分钟的窗口内触发提醒
                        if (rt <= now && (now - rt) <= TimeSpan.FromMinutes(1))
                        {
                            // 弹窗显示提醒内容并播放一次提示音
                            _notifiedReminders.Add(note.Id);
                            // 将主窗口置于前端并临时置顶，以确保用户注意到提醒
                            Application.Current.Dispatcher.Invoke(() =>
                            {
                                try
                                {
                                    var wasTop = Topmost;
                                    Topmost = true;
                                    Activate();
                                    // 播放短音效
                                    try { SystemSounds.Asterisk.Play(); } catch { }
                                    MessageBox.Show($"提醒: {note.DisplayTitle}\n\n{note.Content}", "便签提醒", MessageBoxButton.OK, MessageBoxImage.Information);
                                    Topmost = wasTop;
                                }
                                catch { }
                            });
                        }
                    }
                }
            }
            catch { }
        }

        private bool IsMouseOutOfWindow()
        {
            var mousePos = System.Windows.Forms.Control.MousePosition;
            var winRect = new System.Drawing.Rectangle((int)Left, (int)Top, (int)ActualWidth, (int)ActualHeight);

            // 如果已经贴边，则在判断鼠标是否在窗口外时，考虑贴边后露出的可触发区域（HIDDEN_*）
            if (_isDocked)
            {
                switch (_dockSide)
                {
                    case DockSide.Left:
                        // 向左扩展可视区域，便于鼠标靠近边缘时不会被误判为离开
                        winRect.X -= (int)HIDDEN_WIDTH;
                        winRect.Width += (int)HIDDEN_WIDTH;
                        break;
                    case DockSide.Right:
                        // 向右扩展
                        winRect.Width += (int)HIDDEN_WIDTH;
                        break;
                    case DockSide.Top:
                        // 向上扩展
                        winRect.Y -= (int)HIDDEN_HEIGHT;
                        winRect.Height += (int)HIDDEN_HEIGHT;
                        break;
                    case DockSide.Bottom:
                        // 向下扩展
                        winRect.Height += (int)HIDDEN_HEIGHT;
                        break;
                }
            }

            return !winRect.Contains(mousePos);
        }

        // ============================================================
        // Window Events
        // ============================================================

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var settings = _data.GetSettings();
            Left = settings.WindowLeft;
            Top = settings.WindowTop;
            Width = settings.WindowWidth;
            Height = settings.WindowHeight;

            // 初始化退出位置追踪（防止 LocationChanged 事件晚于预期触发）
            _lastSaveLeft = settings.WindowLeft;
            _lastSaveTop = settings.WindowTop;
            // 仅在首次运行（无设置文件）时默认不置顶；否则保持用户上次设置
            if (!_data.HasSettingsFile())
            {
                Topmost = false;
                settings.AlwaysOnTop = false;
                _data.SaveSettings(settings);
            }
            else
            {
                Topmost = settings.AlwaysOnTop;
            }

            // 同步置顶按钮的图标与提示，使其与实际 Topmost 状态一致
            try
            {
                var tb = (PinButton.Content as TextBlock);
                if (tb != null) tb.Text = Topmost ? "📍" : "📌";
                PinButton.ToolTip = Topmost ? "取消置顶" : "窗口置顶";
            }
            catch { }
            Opacity = settings.Opacity;
            _currentCategoryId = settings.LastCategoryId;

            // 同步开机自启注册表（根据上次用户选择）
            try { SetRunAtStartup(settings.RunAtStartup); } catch { }

            BuildCategoryTabs();
            RefreshNotes();

            // 启动时根据上次保存的位置重新判断贴边状态，
            // 使"贴边自动隐藏"在开机自启后立即生效
            // 同时延迟绑定 LocationChanged/SizeChanged，确保窗口位置稳定后再开始监听变化
            Dispatcher.InvokeAsync(() =>
            {
                CheckDockState();
                if (_isDocked && settings.AutoHideWhenDocked)
                {
                    _autoHideTimer.Stop();
                    _autoHideTimer.Start();
                }

                // 现在窗口位置已稳定，开始监听位置/尺寸变化
                _isLoading = false;
                LocationChanged += Window_LocationChanged;
                SizeChanged += Window_SizeChanged;

                // 记录启动时的最终位置（用于调试）
                try
                {
                    var logPath = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "BlueNotes", "debug_startup.log");
                    System.IO.File.AppendAllText(logPath,
                        $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  STARTUP  " +
                        $"position=({Left:F1},{Top:F1})  size=({ActualWidth:F1}x{ActualHeight:F1})  " +
                        $"settingsRead=({settings.WindowLeft:F1},{settings.WindowTop:F1})  " +
                        $"isDocked={_isDocked}  dockSide={_dockSide}\n");
                }
                catch { }
            }, System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 用户手动关闭窗口 → 最小化到托盘，不退出
            // 注意：系统关机/ExitApp() 触发的 Shutdown 也会走这里，
            // 但 ExitApp() 已经调 SavePositionOnExit() 抢先保存了正确位置
            e.Cancel = true;
            Hide();
        }

        private void Window_LocationChanged(object? sender, EventArgs e)
        {
            CheckDockState();
            SaveWindowState();
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            SaveWindowState();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // 只允许在标题栏拖动（防止误触便签内容）
            if (e.GetPosition(this).Y < 40)
            {
                _isDragging = true;
                DragMove();
                _isDragging = false;
                // 拖拽结束后重新检查贴边状态
                CheckDockState();
            }
        }

        // ============================================================
        // 贴边停靠核心逻辑
        // ============================================================

        private void CheckDockState()
        {
            if (_isHidden || _isAnimating) return;

            var screenWidth = SystemParameters.PrimaryScreenWidth;
            var screenHeight = SystemParameters.PrimaryScreenHeight;

            bool newDockedLeft = Left <= DOCK_THRESHOLD;
            bool newDockedRight = (Left + ActualWidth) >= screenWidth - DOCK_THRESHOLD;
            bool newDockedTop = Top <= DOCK_THRESHOLD;
            bool newDockedBottom = (Top + ActualHeight) >= screenHeight - DOCK_THRESHOLD;

            if (newDockedLeft)
            {
                _isDocked = true;
                _dockSide = DockSide.Left;
                Left = 0;  // 吸附到左边缘，上下位置不变

                _visibleLeft = 0;
                _visibleTop = Top;  // 记录吸附时的纵向位置
                _autoHideTimer.Stop();
                if (_data.GetSettings().AutoHideWhenDocked)
                    _autoHideTimer.Start();
            }
            else if (newDockedRight)
            {
                _isDocked = true;
                _dockSide = DockSide.Right;
                Left = screenWidth - ActualWidth;  // 吸附到右边缘，上下位置不变

                _visibleLeft = Left;
                _visibleTop = Top;  // 记录吸附时的纵向位置
                _autoHideTimer.Stop();
                if (_data.GetSettings().AutoHideWhenDocked)
                    _autoHideTimer.Start();
            }
            else if (newDockedTop)
            {
                _isDocked = true;
                _dockSide = DockSide.Top;
                Top = 0; // 吸附到顶部，左右位置不变

                _visibleLeft = Left;  // 记录吸附时的横向位置
                _visibleTop = 0;
                _autoHideTimer.Stop();
                if (_data.GetSettings().AutoHideWhenDocked)
                    _autoHideTimer.Start();
            }
            else if (newDockedBottom)
            {
                _isDocked = true;
                _dockSide = DockSide.Bottom;
                Top = screenHeight - ActualHeight; // 吸附到底部，左右位置不变

                _visibleLeft = Left;  // 记录吸附时的横向位置
                _visibleTop = Top;
                _autoHideTimer.Stop();
                if (_data.GetSettings().AutoHideWhenDocked)
                    _autoHideTimer.Start();
            }
            else
            {
                _isDocked = false;
                _dockSide = DockSide.None;
                _autoHideTimer.Stop();
            }
        }

        // 滑动隐藏到边缘
        private void SlideHide()
        {
            if (!_isDocked || _isHidden || _isAnimating) return;
            _isHidden = true;
            _isAnimating = true;

            var screenWidth = SystemParameters.PrimaryScreenWidth;
            var screenHeight = SystemParameters.PrimaryScreenHeight;

            if (_dockSide == DockSide.Left || _dockSide == DockSide.Right)
            {
                var targetLeft = _dockSide == DockSide.Left
                    ? -(ActualWidth - HIDDEN_WIDTH)
                    : screenWidth - HIDDEN_WIDTH;
                AnimateLeft(targetLeft, () => _isAnimating = false);
            }
            else if (_dockSide == DockSide.Top || _dockSide == DockSide.Bottom)
            {
                var targetTop = _dockSide == DockSide.Top
                    ? -(ActualHeight - HIDDEN_HEIGHT)
                    : screenHeight - HIDDEN_HEIGHT;
                AnimateTop(targetTop, () => _isAnimating = false);
            }
        }

        // 从边缘滑出
        private void SlideShow()
        {
            if (!_isHidden) return;
            _isHidden = false;
            _isAnimating = true;
            _suppressStateChanged = true; // 动画期间禁止 Windows 最大化干扰

            if (_dockSide == DockSide.Left || _dockSide == DockSide.Right)
                AnimateLeft(_visibleLeft, () => FinishSlideShow());
            else if (_dockSide == DockSide.Top || _dockSide == DockSide.Bottom)
                AnimateTop(_visibleTop, () =>
                {
                    // 上下方向滑出时需要先强制归位，防止 StateChanged
                    // 未拦截时被 Windows 最大化篡改位置
                    if (_dockSide == DockSide.Top)
                        Top = 0;
                    else if (_dockSide == DockSide.Bottom)
                        Top = SystemParameters.PrimaryScreenHeight - ActualHeight;
                    FinishSlideShow();
                });
        }

        private void FinishSlideShow()
        {
            _isAnimating = false;
            _suppressStateChanged = false;
            if (_isDocked && _data.GetSettings().AutoHideWhenDocked)
            {
                _autoHideTimer.Stop();
                _autoHideTimer.Start();
            }
        }

        private void AnimateLeft(double targetLeft, Action? onCompleted = null)
        {
            double startLeft = Left;
            double distance = targetLeft - startLeft;
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var duration = TimeSpan.FromMilliseconds(250);
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            timer.Tick += (s, e) =>
            {
                double progress = Math.Min(1.0, stopwatch.Elapsed.TotalMilliseconds / duration.TotalMilliseconds);
                // CubicEaseOut: 1 - (1 - t)^3
                double eased = 1.0 - Math.Pow(1.0 - progress, 3);
                Left = startLeft + distance * eased;
                if (progress >= 1.0)
                {
                    timer.Stop();
                    onCompleted?.Invoke();
                }
            };
            timer.Start();
        }

        private void AnimateTop(double targetTop, Action? onCompleted = null)
        {
            double startTop = Top;
            double distance = targetTop - startTop;
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var duration = TimeSpan.FromMilliseconds(250);
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            timer.Tick += (s, e) =>
            {
                double progress = Math.Min(1.0, stopwatch.Elapsed.TotalMilliseconds / duration.TotalMilliseconds);
                double eased = 1.0 - Math.Pow(1.0 - progress, 3);
                Top = startTop + distance * eased;
                if (progress >= 1.0)
                {
                    timer.Stop();
                    onCompleted?.Invoke();
                }
            };
            timer.Start();
        }

        private void MainBorder_MouseEnter(object sender, MouseEventArgs e)
        {
            if (_isDocked)
            {
                _autoHideTimer.Stop();
                // 如果当前处于隐藏状态，鼠标进入时直接展示
                if (_isHidden)
                    SlideShow();
            }
        }

        private void MainBorder_MouseLeave(object sender, MouseEventArgs e)
        {
            if (_isDocked && !_isHidden)
            {
                // 只有当鼠标确实离开（考虑贴边时的可触发区域）再启动自动隐藏计时器
                if (IsMouseOutOfWindow())
                {
                    _autoHideTimer.Stop();
                    _autoHideTimer.Start();
                }
            }
        }

        // ============================================================
        // 分类标签构建
        // ============================================================

        private void BuildCategoryTabs()
        {
            CategoryPanel.Children.Clear();
            var categories = _data.GetCategories();

            // 全部按钮
            var allBtn = CreateCategoryButton("📁", "全部便签", "all");
            CategoryPanel.Children.Add(allBtn);

            foreach (var cat in categories.OrderBy(c => c.SortOrder))
            {
                var btn = CreateCategoryButton(cat.Icon, cat.Name, cat.Id);
                CategoryPanel.Children.Add(btn);
            }

            // 新建分类
            var addBtn = new Button
            {
                Content = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Children =
                    {
                        new TextBlock { Text = "＋", FontSize = 12, Margin = new Thickness(0,0,4,0) },
                        new TextBlock { Text = "新建", FontSize = 11 }
                    }
                },
                Style = (Style)FindResource("TabButtonStyle"),
                Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100))
            };
            addBtn.Click += (s, e) => ShowAddCategory();
            CategoryPanel.Children.Add(addBtn);

            // 高亮当前选中
            HighlightCategory(_currentCategoryId);
        }

        private Button CreateCategoryButton(string icon, string name, string categoryId)
        {
            var sp = new StackPanel { Orientation = Orientation.Vertical, HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(new TextBlock { Text = icon, FontSize = 18, HorizontalAlignment = HorizontalAlignment.Center });
            sp.Children.Add(new TextBlock { Text = name, FontSize = 10, HorizontalAlignment = HorizontalAlignment.Center, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });

            // 便签数量
            var noteCount = _data.GetNotes(categoryId == "all" ? null : categoryId).Count(n => !n.IsCompleted);
            if (noteCount > 0)
            {
                sp.Children.Add(new TextBlock
                {
                    Text = noteCount.ToString(),
                    FontSize = 9,
                    Foreground = new SolidColorBrush(Color.FromRgb(180, 100, 0)),
                    HorizontalAlignment = HorizontalAlignment.Center
                });
            }

            var btn = new Button
            {
                Content = sp,
                Style = (Style)FindResource("TabButtonStyle"),
                Tag = categoryId,
                Width = 80
            };
            btn.Click += CategoryButton_Click;
            // 右键菜单：始终提供“清理全部便签”；对于非系统分类（排除“全部”）再提供“删除分类”
            var context = new ContextMenu();

            var clearAll = new MenuItem { Header = "清理全部便签" };
            clearAll.Click += (s, e) =>
            {
                if (MessageBox.Show("将清理全部便签，不可恢复，是否继续", "清理确认", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    // 删除该分类下的所有便签（全部分类传入 null）
                    var notes = _data.GetNotes(categoryId == "all" ? null : categoryId).ToList();
                    foreach (var n in notes)
                        _data.DeleteNote(n.Id);

                    // 刷新 UI
                    BuildCategoryTabs();
                    RefreshNotes();
                }
            };
            context.Items.Add(clearAll);

            // 若为可删除的自定义分类，添加“删除分类”项（会同时删除分类及其便签）
            if (categoryId != "all")
            {
                var cat = _data.GetCategories().FirstOrDefault(c => c.Id == categoryId);
                if (cat == null || !cat.IsSystem)
                {
                    context.Items.Add(new Separator());
                    var del = new MenuItem { Header = "删除分类" };
                    del.Click += (s, e) =>
                    {
                        if (MessageBox.Show($"确认删除分类“{name}”？此操作会删除该分类下的所有便签。", "删除确认", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                        {
                            // 先删除该分类下的便签
                            var notes = _data.GetNotes(categoryId == "all" ? null : categoryId).ToList();
                            foreach (var n in notes)
                                _data.DeleteNote(n.Id);

                            // 删除分类
                            _data.DeleteCategory(categoryId);
                            _currentCategoryId = "all";
                            BuildCategoryTabs();
                            RefreshNotes();
                        }
                    };
                    context.Items.Add(del);
                }
            }

            btn.ContextMenu = context;
            return btn;
        }

        private void HighlightCategory(string categoryId)
        {
            foreach (Button btn in CategoryPanel.Children.OfType<Button>())
            {
                if (btn.Tag?.ToString() == categoryId)
                {
                    btn.Background = new SolidColorBrush(Color.FromRgb(255, 230, 100));
                    btn.FontWeight = FontWeights.SemiBold;
                }
                else
                {
                    btn.Background = new SolidColorBrush(Color.FromRgb(200, 235, 200));
                    btn.FontWeight = FontWeights.Normal;
                }
            }
        }

        private void CategoryButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string catId)
            {
                _currentCategoryId = catId;
                HighlightCategory(catId);
                UpdateTitle(catId);
                RefreshNotes();
            }
        }

        private void UpdateTitle(string categoryId)
        {
            if (categoryId == "all")
            {
                TitleIcon.Text = "📁";
                TitleText.Text = "全部 综合";
                return;
            }
            var cat = _data.GetCategories().FirstOrDefault(c => c.Id == categoryId);
            if (cat != null)
            {
                TitleIcon.Text = cat.Icon;
                TitleText.Text = cat.Name;
            }
        }

        // ============================================================
        // 便签列表渲染
        // ============================================================

        private void RefreshNotes()
        {
            NotesPanel.Children.Clear();
            var catId = _currentCategoryId == "all" ? null : _currentCategoryId;
            var notes = _data.GetNotes(catId)
                .Where(n => _showCompleted ? (n.IsCompleted || n.IsAbandoned) : (!n.IsCompleted && !n.IsAbandoned))
                .Where(n => string.IsNullOrEmpty(_searchText) ||
                            n.Title.Contains(_searchText, StringComparison.OrdinalIgnoreCase) ||
                            n.Content.Contains(_searchText, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(n => n.IsPinned)
                .ThenByDescending(n => n.UpdatedAt)
                .ToList();

            EmptyHint.Visibility = notes.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            foreach (var note in notes)
                NotesPanel.Children.Add(CreateNoteCard(note));
        }

        private UIElement CreateNoteCard(Note note)
        {
            var bg = (Color)ColorConverter.ConvertFromString(note.ColorHex);
            var headerBg = (Color)ColorConverter.ConvertFromString(note.HeaderColorHex);

            var card = new Border
            {
                Background = new SolidColorBrush(bg),
                CornerRadius = new CornerRadius(6),
                Margin = new Thickness(0, 0, 0, 6),
                Cursor = Cursors.Hand,
                Tag = note.Id
            };
            card.Effect = new System.Windows.Media.Effects.DropShadowEffect
            {
                Color = Colors.Black,
                BlurRadius = 4,
                ShadowDepth = 1,
                Opacity = 0.15
            };

            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // 标题行
            var headerBorder = new Border
            {
                Background = new SolidColorBrush(headerBg),
                CornerRadius = new CornerRadius(6, 6, 0, 0),
                Padding = new Thickness(8, 4, 8, 4)
            };
            var headerGrid = new Grid();
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleText = new TextBlock
            {
                Text = (note.IsPinned ? "📌 " : "") + note.DisplayTitle,
                FontWeight = FontWeights.SemiBold,
                FontSize = 12,
                Foreground = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(titleText, 0);
            headerGrid.Children.Add(titleText);

            // 操作按钮
            var actionPanel = new StackPanel { Orientation = Orientation.Horizontal };

            // 如果设置了提醒且未超过 1 分钟的过期窗口，则在编辑按钮前显示提醒图标
            if (note.ReminderTime.HasValue)
            {
                var rt = note.ReminderTime.Value;
                if (rt.Kind == DateTimeKind.Utc)
                    rt = rt.ToLocalTime();
                else if (rt.Kind == DateTimeKind.Unspecified)
                    rt = DateTime.SpecifyKind(rt, DateTimeKind.Local);

                var now = DateTime.Now;
                // 显示条件：提醒时间在将来，或已到但不超过1分钟
                if (rt > now || (now - rt) <= TimeSpan.FromMinutes(1))
                {
                    var hint = new TextBlock
                    {
                        Text = "⏰",
                        FontSize = 11,
                        VerticalAlignment = VerticalAlignment.Center,
                        Margin = new Thickness(0, 0, 4, 0),
                        ToolTip = $"提醒：{rt:yyyy-MM-dd HH:mm}"
                    };
                    actionPanel.Children.Add(hint);
                }
            }

            actionPanel.Children.Add(CreateMiniButton("✏️", "编辑", (s, e) => EditNote(note.Id)));
            actionPanel.Children.Add(CreateMiniButton("🗑️", "删除", (s, e) => DeleteNote(note.Id)));
            Grid.SetColumn(actionPanel, 1);
            headerGrid.Children.Add(actionPanel);

            headerBorder.Child = headerGrid;
            Grid.SetRow(headerBorder, 0);
            grid.Children.Add(headerBorder);

            // 内容
            var contentText = new TextBlock
            {
                Text = note.Content,
                FontSize = 11,
                Foreground = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(8, 6, 8, 6),
                MaxHeight = 80,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetRow(contentText, 1);
            grid.Children.Add(contentText);

            card.Child = grid;
            card.MouseLeftButtonDown += (s, e) => EditNote(note.Id);
            return card;
        }

        private Button CreateMiniButton(string icon, string tip, RoutedEventHandler handler)
        {
            var btn = new Button
            {
                Content = new TextBlock { Text = icon, FontSize = 11 },
                Style = (Style)FindResource("IconButtonStyle"),
                ToolTip = tip,
                Padding = new Thickness(2)
            };
            btn.Click += handler;
            return btn;
        }

        // ============================================================
        // 便签操作
        // ============================================================

        private void AddNote_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new NoteEditWindow(_currentCategoryId == "all" ? "normal" : _currentCategoryId)
            {
                Owner = this
            };
            if (dlg.ShowDialog() == true && dlg.ResultNote != null)
            {
                _data.AddNote(dlg.ResultNote);
                BuildCategoryTabs();
                RefreshNotes();
            }
        }

        private void EditNote(string id)
        {
            var note = _data.GetNotes().FirstOrDefault(n => n.Id == id);
            if (note == null) return;

            var dlg = new NoteEditWindow(note) { Owner = this };
            if (dlg.ShowDialog() == true && dlg.ResultNote != null)
            {
                _data.UpdateNote(dlg.ResultNote);
                BuildCategoryTabs();
                RefreshNotes();
            }
        }

        private void DeleteNote(string id)
        {
            var result = MessageBox.Show("确认删除这条便签？", "删除确认",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                _data.DeleteNote(id);
                BuildCategoryTabs();
                RefreshNotes();
            }
        }

        // ============================================================
        // 工具栏事件
        // ============================================================

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            SearchPanel.Visibility = SearchPanel.Visibility == Visibility.Collapsed
                ? Visibility.Visible : Visibility.Collapsed;
            if (SearchPanel.Visibility == Visibility.Visible)
                SearchBox.Focus();
        }

        private void CloseSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchPanel.Visibility = Visibility.Collapsed;
            _searchText = "";
            SearchBox.Text = "";
            RefreshNotes();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _searchText = SearchBox.Text;
            RefreshNotes();
        }

        private void PinWindow_Click(object sender, RoutedEventArgs e)
        {
            Topmost = !Topmost;
            var settings = _data.GetSettings();
            settings.AlwaysOnTop = Topmost;
            _data.SaveSettings(settings);
            // PinButton.Content 在 XAML 中设置为 TextBlock，因此安全转换并更新其文本
            if (PinButton.Content is TextBlock tbContent)
            {
                tbContent.Text = Topmost ? "📍" : "📌";
            }
            // 同步按钮 ToolTip
            PinButton.ToolTip = Topmost ? "取消置顶" : "窗口置顶";
        }

        private void MinimizeWindow_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void ShowMenu_Click(object sender, RoutedEventArgs e)
        {
            var menu = new ContextMenu();

            var autoHideItem = new MenuItem
            {
                Header = _data.GetSettings().AutoHideWhenDocked ? "取消贴边自动隐藏" : "启用贴边自动隐藏",
            };
            autoHideItem.Click += (s, e) =>
            {
                var st = _data.GetSettings();
                st.AutoHideWhenDocked = !st.AutoHideWhenDocked;
                _data.SaveSettings(st);
                autoHideItem.Header = st.AutoHideWhenDocked ? "取消贴边自动隐藏" : "启用贴边自动隐藏";
            };
            menu.Items.Add(autoHideItem);

            menu.Items.Add(new Separator());

            // 开机运行菜单项
            var settings = _data.GetSettings();
            var runAtStartupItem = new MenuItem
            {
                Header = "开机运行",
                IsCheckable = true,
                IsChecked = settings.RunAtStartup
            };
            runAtStartupItem.Click += (s, e) =>
            {
                try
                {
                    var st = _data.GetSettings();
                    st.RunAtStartup = !st.RunAtStartup;
                    _data.SaveSettings(st);
                    runAtStartupItem.IsChecked = st.RunAtStartup;
                    SetRunAtStartup(st.RunAtStartup);
                }
                catch
                {
                    MessageBox.Show("设置开机自启失败。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };
            menu.Items.Add(runAtStartupItem);


            menu.Items.Add(new MenuItem
            {
                Header = "导出便签数据",
                Command = new RelayCommand(ExportData)
            });

            menu.Items.Add(new MenuItem
            {
                Header = "导入便签数据",
                Command = new RelayCommand(ImportData)
            });

            menu.Items.Add(new Separator());

            var opacityMenu = new MenuItem { Header = "透明度" };
            var currentOpacity = _data.GetSettings().Opacity;
            foreach (var op in new[] { 1.0, 0.9, 0.8, 0.7, 0.6 })
            {
                var val = op;
                var item = new MenuItem
                {
                    Header = $"{(int)(op * 100)}%",
                    IsCheckable = true,
                    IsChecked = Math.Abs(currentOpacity - val) < 0.001
                };
                item.Click += (s, e) =>
                {
                    // 更新透明度并保存设置
                    Opacity = val;
                    var st = _data.GetSettings();
                    st.Opacity = val;
                    _data.SaveSettings(st);

                    // 更新同组项的选中状态
                    foreach (MenuItem mi in opacityMenu.Items.OfType<MenuItem>())
                        mi.IsChecked = false;
                    item.IsChecked = true;
                };
                opacityMenu.Items.Add(item);
            }
            menu.Items.Add(opacityMenu);

            // 关于信息
            var aboutItem = new MenuItem { Header = "关于" };
            aboutItem.Click += (s, e) =>
            {
                try
                {
                    var asm = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
                    var version = asm.GetName().Version?.ToString() ?? "1.0.0";
                    var buildTime = File.GetLastWriteTime(asm.Location).ToString("yyyy-MM-dd HH:mm:ss");
                    var msg = $"版本: {version}\n编译时间: {buildTime}\n作者: 张光炬\n邮箱: 76253589@QQ.COM";
                    MessageBox.Show(msg, "关于", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("关于信息获取失败。", "关于", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            };
            menu.Items.Add(aboutItem);

            menu.Items.Add(new Separator());
            menu.Items.Add(new MenuItem
            {
                Header = "退出程序",
                Command = new RelayCommand(() =>
                {
                    if (MessageBox.Show("确认退出桌面便签？", "退出", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        (Application.Current as App)?.Dispatcher.Invoke(() =>
                        {
                            // 真正退出
                            Application.Current.Shutdown();
                        });
                    }
                })
            });

            menu.IsOpen = true;
        }

        private void ShowCategoryMenu(object sender, MouseButtonEventArgs e)
        {
            BuildCategoryTabs();
        }

        private void SubFilter_Click(object sender, MouseButtonEventArgs e)
        {
            // 切换今日/全部过滤
        }

        private void CompletedFilter_Click(object sender, MouseButtonEventArgs e)
        {
            _showCompleted = !_showCompleted;
            CompletedFilter.Foreground = _showCompleted
                ? new SolidColorBrush(Colors.DarkOrange)
                : new SolidColorBrush(Color.FromRgb(153, 153, 153));
            RefreshNotes();
        }

        // ============================================================
        // 分类管理
        // ============================================================

        private void ShowAddCategory()
        {
            var dlg = new InputDialog("新建分类", "请输入分类名称：") { Owner = this };
            if (dlg.ShowDialog() == true && !string.IsNullOrWhiteSpace(dlg.Result))
            {
                _data.AddCategory(new NoteCategory { Name = dlg.Result, Icon = "📂" });
                BuildCategoryTabs();
            }
        }

        // ============================================================
        // 导入导出
        // ============================================================

        private void ExportData()
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title = "导出便签数据",
                Filter = "JSON文件|*.json",
                FileName = $"BlueNotes_{DateTime.Now:yyyyMMdd}"
            };
            if (dlg.ShowDialog() == true)
            {
                System.IO.File.WriteAllText(dlg.FileName, _data.ExportToJson());
                MessageBox.Show("导出成功！", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ImportData()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "导入便签数据",
                Filter = "JSON文件|*.json"
            };
            if (dlg.ShowDialog() == true)
            {
                var json = System.IO.File.ReadAllText(dlg.FileName);
                if (_data.ImportFromJson(json))
                {
                    BuildCategoryTabs();
                    RefreshNotes();
                    MessageBox.Show("导入成功！", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("导入失败，文件格式不正确。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // ============================================================
        // 状态保存
        // ============================================================
        // 供 App.ExitApp() 在 Shutdown 前显式调用
        public void SavePositionOnExit()
        {
            _isExiting = true; // 锁死后续所有 SaveWindowState，防止覆盖

            try
            {
                var settings = _data.GetSettings();
                var sw = SystemParameters.PrimaryScreenWidth;
                var sh = SystemParameters.PrimaryScreenHeight;
                var w = ActualWidth > 0 ? ActualWidth : Width;
                var h = ActualHeight > 0 ? ActualHeight : Height;

                // 直接根据贴边状态正向计算可见位置（不依赖任何追踪字段）
                double saveLeft, saveTop;
                if (_isDocked)
                {
                    switch (_dockSide)
                    {
                        case DockSide.Left:
                            saveLeft = 0; saveTop = _visibleTop; break;
                        case DockSide.Right:
                            saveLeft = sw - w; saveTop = _visibleTop; break;
                        case DockSide.Top:
                            saveLeft = _visibleLeft; saveTop = 0; break;
                        case DockSide.Bottom:
                            saveLeft = _visibleLeft; saveTop = sh - h; break;
                        default:
                            saveLeft = _lastSaveLeft > 0 ? _lastSaveLeft : Left;
                            saveTop = _lastSaveTop > 0 ? _lastSaveTop : Top;
                            break;
                    }
                }
                else
                {
                    saveLeft = Left;
                    saveTop = Top;
                }

                settings.WindowLeft = saveLeft;
                settings.WindowTop = saveTop;
                settings.WindowWidth = w;
                settings.WindowHeight = h;
                settings.LastCategoryId = _currentCategoryId;
                _data.SaveSettings(settings);

                // 写入后立即读回验证
                var verifyJson = System.IO.File.ReadAllText(
                    System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "BlueNotes", "settings.json"));
                var writtenLeft = "?";
                var writtenTop = "?";
                try
                {
                    var match = System.Text.RegularExpressions.Regex.Match(verifyJson,
                        "\"WindowLeft\":\\s*([\\d.]+)");
                    if (match.Success) writtenLeft = match.Groups[1].Value;
                    match = System.Text.RegularExpressions.Regex.Match(verifyJson,
                        "\"WindowTop\":\\s*([\\d.]+)");
                    if (match.Success) writtenTop = match.Groups[1].Value;
                }
                catch { }

                // 调试日志
                var logPath = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "BlueNotes", "debug_exit.log");
                System.IO.File.AppendAllText(logPath,
                    $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  EXIT  dockSide={_dockSide}  " +
                    $"isHidden={_isHidden}  saved=({saveLeft:F1},{saveTop:F1})  " +
                    $"current=({Left:F1},{Top:F1})  verified=({writtenLeft},{writtenTop})  " +
                    $"screen=({sw},{sh})  size=({w}x{h})\n");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"SavePositionOnExit failed: {ex.Message}");
            }
        }

        private void SaveWindowState()
        {
            // 隐藏/动画/退出/加载期间不保存文件，避免覆盖退出时的正确位置
            if (_isHidden || _isAnimating || _isExiting || _isLoading) return;

            try
            {
                _lastSaveLeft = Left;
                _lastSaveTop = Top;

                var settings = _data.GetSettings();
                settings.WindowLeft = _lastSaveLeft;
                settings.WindowTop = _lastSaveTop;
                settings.WindowWidth = ActualWidth > 0 ? ActualWidth : Width;
                settings.WindowHeight = ActualHeight > 0 ? ActualHeight : Height;
                settings.LastCategoryId = _currentCategoryId;
                _data.SaveSettings(settings);
            }
            catch
            {
                // 静默忽略保存失败，避免影响正常操作
            }
        }
        // 设置或取消开机自启（使用当前用户的注册表 Run 键）
        private void SetRunAtStartup(bool enable)
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                if (key == null) return;
                var name = "BlueNotes";
                if (enable)
                {
                    // 尽量写入可直接运行的命令行：
                    // - 若入口程序集是 .dll 且当前进程为 dotnet 等宿主进程，则写入: "<宿主路径>" "<dll路径>"
                    // - 否则写入可执行文件路径: "<exe路径>"
                    var entryPath = Assembly.GetEntryAssembly()?.Location;
                    var processPath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;

                    if (!string.IsNullOrEmpty(entryPath))
                    {
                        var ext = System.IO.Path.GetExtension(entryPath) ?? "";
                        if (ext.Equals(".dll", StringComparison.OrdinalIgnoreCase) &&
                            !string.IsNullOrEmpty(processPath) &&
                            !string.Equals(System.IO.Path.GetFileName(processPath), System.IO.Path.GetFileName(entryPath), StringComparison.OrdinalIgnoreCase))
                        {
                            // 运行形如: "C:\path\to\dotnet.exe" "C:\path\to\app.dll"
                            key.SetValue(name, $"\"{processPath}\" \"{entryPath}\"");
                        }
                        else
                        {
                            // 运行形如: "C:\path\to\app.exe"
                            key.SetValue(name, $"\"{entryPath}\"");
                        }
                    }
                }
                else
                {
                    key.DeleteValue(name, false);
                }
            }
            catch { }
        }

    }

    // ============================================================
    // RelayCommand 辅助类
    // ============================================================
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        public RelayCommand(Action execute) => _execute = execute;
#pragma warning disable CS0067
        public event EventHandler? CanExecuteChanged;
#pragma warning restore CS0067
        public bool CanExecute(object? parameter) => true;
        public void Execute(object? parameter) => _execute();
    }
}
